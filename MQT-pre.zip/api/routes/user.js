//Configuracion de rutas del controlador de usuarios
'use strict'
var express = require('express');
var UserController=require('../controllers/user');
var api = express.Router();

//Definir las rutas
api.get('/home', UserController.home);
api.get('/pruebas', UserController.pruebas);
api.post('/register', UserController.saveUser);
api.post('/login', UserController.loginUser)

module.exports=api;